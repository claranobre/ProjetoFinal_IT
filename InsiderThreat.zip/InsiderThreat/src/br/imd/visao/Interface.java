package br.imd.visao;

public class Interface {
	
	public void montagemPerfil(){}
	
	public void visualizacaoPerfil(){}
	
	public void deteccaoAnomalia(){}
	
	public void leituraDeArquivo(){}
	
	public void criacaoHistograma(){}
}