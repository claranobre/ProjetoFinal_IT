package br.imd.controle;

public class Device {
	private String tipoDevice;
	private int codID;
	
	public Device(){}
	
	public void atividadesExecutadas(){}
	
	public String getTipoDevice() {
		return tipoDevice;
	}
	public void setTipoDevice(String tipoDevice) {
		this.tipoDevice = tipoDevice;
	}
	public int getCodID() {
		return codID;
	}
	public void setCodID(int codID) {
		this.codID = codID;
	}
}