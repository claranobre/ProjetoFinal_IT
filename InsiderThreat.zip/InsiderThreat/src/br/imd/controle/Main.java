package br.imd.controle;


public class Main extends LeituraLog{

	public static void main(String[] args) {
		String csvLogon = ("Dados/logon-sumarizado.csv");
		String csvDevice = ("/Dados/device.csv");
		String csvHTTP = ("Dados/http-completo.csv");
		String csvLDAP = ("Dados/ldap.csv");
		
		//leituraArquivoLogon(csvLogon);
		//leituraArquivoDevice(csvDevice);
		//leituraArquivoHTTP(csvHTTP);
		//leituraArquivoLDAP(csvLDAP);
	}

}