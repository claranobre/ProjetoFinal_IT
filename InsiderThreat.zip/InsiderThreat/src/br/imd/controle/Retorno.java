package br.imd.controle;

import java.util.ArrayList;

public class Retorno {
	private ArrayList<String> acaoUsuario;
	
	private void respostaAtributo(){}
	
}
