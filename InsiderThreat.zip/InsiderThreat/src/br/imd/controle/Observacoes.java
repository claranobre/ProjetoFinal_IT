package br.imd.controle;

import java.util.ArrayList;

public class Observacoes {
	private ArrayList<String> diasSemana;
	
	public void diaCorrente(){}
	
	public void anteriores(){}
	
	public void suspeitas(){}
}
